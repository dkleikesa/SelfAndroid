##Android问题
### MVP 、MVC、MVVM
1. MVC： model、view、controller
model：数据提供以及主要业务逻辑
view：界面，只负责展现，没有业务逻辑
controller：尽量少的业务逻辑以及 model和view的桥接
工作流程：用户一个操作，view发送给controller，controller处理完，更新数据model，然后view根据model来更新展示，三者之间是环形关系。
![Alt text](./1527215459211.png)

2. MVP：model、view、presenter
model：数据提供以及业务逻辑
view：界面，负责展现
presenter：业务逻辑，以及model和view之间的桥梁，通过model和view的接口将两者关联起来
工作流程：用户一个操作，view发送给presenter来处理，如果有数据变更，则有presenter 操作更新mode，model处理完以后，结果通过presenter反馈给view，三者是双向链表形式。
![Alt text](./1527215728414.png)

3. MVVM
model：数据提供以及主要业务逻辑
view：界面，负责展现
viewModel：业务逻辑，以及数据绑定相关，同时比presenter更轻量级，是拆小的presenter
工作流程：用户一个操作，view将操作发送给viewModel，viewModel处理业务逻辑，如果有数据的更改，则通过数据绑定，直接更新model，model的数据更新，也直接通过数据绑定，反馈在view上。viewModel和presenter的最大区别是数据绑定（data binding）上，presenter 需要完成 view和model之间互相操作的逻辑， viewmodel通过 数据绑定来解决了这个问题，从而精简了部分代码。
![Alt text](./1527487764216.png)



### bundle化
1. wing框架干的事情
 * APP启动流程
 * bundle初始化
 * bundle间通信
 * 页面框架
 * scheme分发